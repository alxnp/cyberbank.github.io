Mori-Dark
=========

An HTML5 minimalistic super-responsive portfolio and blog template.

CSS-only hexagon hive gallery!

http://mori-dark.s3-website.eu-central-1.amazonaws.com/
